import { Injectable } from '@angular/core';
import { Product } from '../model/product.model';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  private products: Product[] = [];
  private API_SERVER = 'https://localhost:5001/Product/';
  invalidLogin: boolean = true;

  constructor(private http: HttpClient) { }

  get() : Observable<Product[]> {

    return this.http.get<Product[]>(this.API_SERVER);
    
  }

  getById(id: number) : Observable<Product> {
    return this.http.get<Product>(this.API_SERVER + id);
  }

  getProduct(id: number) : Product {
    
    let res: Product= new Product(0, '', 0, '','');
    //debugger;
    this.getById(id).subscribe(
      (data: Product) => {
        res.id = data.id;
        res.name = data.name;
        res.price = data.price;
        res.photoPath = data.photoPath;
        res.description=data.description;
      }

    );

    return res;
  }



 /*  constructor() { 
     this.products = [
      {
        id: 1,
        name: 'Watch1',
        price: 111.15,
        photoPath: 'assets/images/appleWatch.jpg',
        description:"here same description"
      },
      {
        id: 2,
        name: 'Watch2',
        price: 1110.99,
        photoPath: 'assets/images/cartier.jpg',
        description:"here same description"
      },
      {
        id: 3,
        name: 'Watch3',
        price: 99.99,
        photoPath: 'assets/images/kidswatch.jpg',
        description:"here same description"
      },
      {
        id: 4,
        name: 'Watch4',
        price: 499.99,
        photoPath: 'assets/images/rolex.jpg',
        description:"here same description"
      },

   {
        id: 5,
        name: 'Watch',
        price: 220.99,
        photoPath: 'assets/images/noname.jpg',
        description:"here same description"
       
      },
      {
        id: 6,
        name: 'Cartier',
        price: 450.99,
        photoPath: 'assets/images/cartierorange.jpg',
        description:"here same description"
      },
    ];
  } */

  getProducts(): Product[] {
    
    return this.products;
  }
  
  private getSelectedIndex(id: number) {
    for(var i = 0; this.getProducts.length; ++i) {
      
      if(this.products[i].id == id) {
        return i;
      }
    }

    return -1;
  }


  addProduct(pro:Product) {
    
    this.products.push(pro);
  }
}