import { Component, OnInit } from '@angular/core';
import {Product} from '../../model/product.model';
import { ProductService } from '../../services/product.service';
@Component({
 // selector: 'app-listproducts',
  templateUrl: './listproducts.component.html',
  styleUrls: ['./listproducts.component.css']
})
   export class ListproductsComponent implements OnInit {
 // @Input()
  products?:Product[] ;

  constructor(private service:ProductService) { }

   ngOnInit(): void {
      // this.products =this.service.getProducts();

    this.service.get()
    .subscribe(
      (data: Product[]) => {
        this.products= data;
      });
    }

  

  addCartData(id?: number, qty?: number) : void {
    let itemExists = false;
    let cartData = localStorage.getItem( 'cartData' ) || '[]';
    let json = JSON.parse(cartData);
    
    for (let i = 0; i < json.length; i++) {
      let cartItemObject = JSON.parse(json[i]);
      if (cartItemObject.id == id) {
        let newQ = cartItemObject.qty + qty;
        cartItemObject.qty = newQ;
        itemExists = true;
        json[i] = JSON.stringify(cartItemObject);
      }
    }
    if (!itemExists) {

    json.push( JSON.stringify( {'id': id, 'qty': qty } ) );
    }
    localStorage.setItem(  'cartData', JSON.stringify(json) );

   // console.log( localStorage.getItem('cartData') );
  }

  clearCartData() : void {
    localStorage.setItem( 'cartData', '' );
    console.log( localStorage.getItem('cartData') );
  }

  ifLogin() {
    return !this.service.invalidLogin;
  }

  }

